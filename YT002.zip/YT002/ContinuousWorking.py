import cv2
from datetime import datetime

class VideoStream:
    def __init__(self, overlay_path, output_directory='Repository/Recording', codec='XVID', fps=30.0):
        # Load the overlay image with transparency (if any)
        self.overlay = cv2.imread(overlay_path, cv2.IMREAD_UNCHANGED)

        # Open a connection to the webcam
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            raise Exception("Error: Could not open webcam.")

        # Get the dimensions of the webcam video
        self.frame_width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.frame_height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        # Resize the overlay to a smaller size (e.g., 1/4th of the frame size)
        self.overlay_scale = 0.25
        self.overlay_resized = cv2.resize(self.overlay, 
                                         (int(self.frame_width * self.overlay_scale), 
                                          int(self.frame_height * self.overlay_scale)))
        self.overlay_height, self.overlay_width = self.overlay_resized.shape[:2]

        # Define the codec
        self.fourcc = cv2.VideoWriter_fourcc(*codec)

        # Generate a timestamp for the filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.filename = f'{output_directory}/Output_{timestamp}.mp4'

        # Create the VideoWriter object with the timestamped filename
        self.out = cv2.VideoWriter(self.filename, self.fourcc, fps, (self.frame_width, self.frame_height))

    def start_recording(self):
        while True:
            ret, frame = self.cap.read()
            if ret:
                # Save the original frame for recording
                frame_for_recording = frame.copy()

                # Calculate the position to place the overlay at the center
                x_offset = (self.frame_width - self.overlay_width) // 2
                y_offset = (self.frame_height - self.overlay_height) // 2

                # Extract the region of interest (ROI) where the overlay will be placed
                roi = frame[y_offset:y_offset+self.overlay_height, x_offset:x_offset+self.overlay_width]

                # Ensure the overlay has 4 channels (RGBA)
                if self.overlay_resized.shape[2] == 4:
                    alpha_overlay = self.overlay_resized[:, :, 3] / 255.0
                    alpha_frame = 1.0 - alpha_overlay

                    # Blend the overlay with the ROI
                    for c in range(0, 3):
                        roi[:, :, c] = (alpha_overlay * self.overlay_resized[:, :, c] + alpha_frame * roi[:, :, c])

                # Write the frame (with or without overlay) to the output file
                self.out.write(frame_for_recording)

                # Exit the loop when 'q' is pressed
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
            else:
                break

    def release_resources(self):
        # Release the webcam and file handles, and close any open windows
        self.cap.release()
        self.out.release()
        cv2.destroyAllWindows()

# Example usage:
if __name__ == "__main__":
    video_stream = VideoStream(overlay_path='Crosshair.png')
    try:
        video_stream.start_recording()
    finally:
        video_stream.release_resources()
